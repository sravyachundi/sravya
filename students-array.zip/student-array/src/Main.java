public class Main {

	public static void main(String[] args) {
		
		//You may test that your code works find here
		//Please check that your code works and has no 
		//compilation problems before to submit
		
		int id1;
		int i;
		String name;
		Date d;
		double avg;
		int num;
		Scanner s=new scanner(System.in);
		num=s.nextInt();
		for(i=0;i<num;i++){
			id1=s.nextInt();
			name=s.nextLine();
			d=s.nextLine();
			avg=s.nextDouble();
			Students s=new Student(id1,name,d,avg);
		}
		Student s1=new Student();
		s1.setId(1);
		s1.setFullName("aaaa");
		s1.setBirthDate("07-24-1997");
		s1.setAvgMark(80.00);
		int id2=s1.getId();
		String name1=s1.getFullName();
		Date d1=s1.getBirthDate();
		double avg1=s1.getAvgMark();
		
	}

}
